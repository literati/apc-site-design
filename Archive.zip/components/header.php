
    <nav class="top-bar contain-to-grid">
      <ul>
        <li class="name">
          <h1>
            <a href="index.php">ANTEBELLUM PRINT CULUTRE</a>
          </h1>
        </li>
        <li class="toggle-topbar">
          <a href="#"></a>
        </li>
      </ul>
      <section>
        <ul class="right">
          <li class="has-dropdown">
            <a href="http://literati.cct.lsu.edu/omeka/">ARCHIVE</a>
            <ul class="dropdown">
              <li>
                <a href="http://literati.cct.lsu.edu/omeka/collections/show/1">Tales</a>
              </li>
              <li>
                <a href="http://literati.cct.lsu.edu/omeka/collections/show/2">Magazines</a>
              </li>
              <li>
                <a href="http://literati.cct.lsu.edu/omeka/collections/show/3">Illustrations</a>
              </li>
              <li>
                <a href="http://literati.cct.lsu.edu/omeka/collections/show/4">Books</a>
              </li>
            </ul>
          </li>
          <li class="has-dropdown">
            <a href="#">STORIES</a>
            <ul class="dropdown">
              <li>
                <a href="exploremummy.php">Some Words with a Mummy</a>
              </li>
              <li>
                <a href="explorebox.php">The Oblong Box</a>
              </li>
              <li>
                <a href="exploremountains.php">A Tale of the Ragged Mountains</a>
              </li>
            </ul>
          </li>
        </ul>
      </section>
    </nav>
